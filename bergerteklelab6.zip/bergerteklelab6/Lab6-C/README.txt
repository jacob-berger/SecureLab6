Daniel Tekle
Jacob Berger

Shortcomings
if the user enters a large value for either int, the number becomes -1
if spaces are used in user input, only the first token is captured
filename input is limited to a few special characters

Compiling
gcc -pedantic -Wall -Wextra -Werror -m32 cscd437Lab6Main.c aes.c aes.h