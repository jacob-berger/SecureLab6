Daniel Tekle
Jacob Berger

Shortcomings
filename input is limited to a few special characters

Compiling
javac *.java